score= float(input("What is your score?"))
if score>=90:
    print('Your Score is A')
elif score>=80:
    print('Your Score is B')
elif score>=70:
    print('Your Score is C')
elif score>=60:
    print('Your Score is D')
elif score<60:
    print('Your Score is F')
