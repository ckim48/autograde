x = int(input("Enter your score: "))
if x >= 90:
    print("Your score is A")
elif x >= 80:
    print("Your score is B")
elif x >= 70:
    print("Your score is C")
elif x >= 60:
    print("Your score is D")
elif x < 60:
    print("Your score is F")


